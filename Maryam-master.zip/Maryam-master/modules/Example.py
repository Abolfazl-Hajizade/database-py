from core.module import BaseModule

class Module(BaseModule):

    meta = {
        "name": "<Module-Name>",
        "author": "saeeddhqan",
        "description": "<Description>",
        "comments": (
            "<comment1>",
            "<comment2>"
        ),
        "options": (
            ("url", "127.0.0.1", True, "<desc..>"),
            ("limit", 100, True, "limit for search(max=1000)")
        )
    }

    def module_run(self):
        url = self.options["url"]
        limit = self.options["limit"]
        #  dir(self) # show tools
