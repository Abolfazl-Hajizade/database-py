[![Donate US](https://img.shields.io/badge/Donate-OWASP-green.svg)](https://www.owasp.org/index.php?title=OWASP_Maryam_Project)
![Version 1.3](https://img.shields.io/badge/Version-1.3-green.svg)
[![GPLv3 License](https://img.shields.io/badge/License-GPLv3-red.svg)
![Python 2.x](https://img.shields.io/badge/Python-2.x-green.svg)
![Python 3.x](https://img.shields.io/badge/Python-3.x-green.svg)

OWASP Maryam Framework
====

Maryam is a framework written by the Python language.
Maryam is a kernel ready for those who want to have a framework for their web scanners.

### why?
With Maryam you just have to write your modules and use them easily.
Maryam includes predefined tools and a ready CUI interface that makes it easy for you to write a web scanner framework.
