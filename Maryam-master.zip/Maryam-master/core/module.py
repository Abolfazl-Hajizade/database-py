# -*- coding: utf-8 -*-

from __future__ import print_function
import cookielib
import hashlib
import hmac
import HTMLParser
import os
import re
import socket
import sqlite3
import struct
import sys
import textwrap
import time
import urllib
import urlparse
# framework libs
from core import framework
from core.util import web_scrap
from core.util import reglib
from core.util import urlib
from core.util import google_engine
from core.util import bing_engine
from core.util import yahoo_engine
from core.util import baidu_engine
from core.util import yandex_engine
from core.util import ask_engine
from core.util import page_parse
from core.util import wordlists
from core.util import reverse_ip
from core.util import dns_find
from core.util import emails_find
from core.util import godork
from core.util import social_nets
from core.util import page_search

# =================================================
# MODULE CLASS
# =================================================


class BaseModule(framework.Framework):

	def __init__(self, params, query=None):
		framework.Framework.__init__(self, params)
		self.options = framework.Options()
		# register all other specified options
		if(self.meta.get("options")):
			for option in self.meta.get("options"):
				self.register_option(*option)
		self._reload = 0

	# ==================================================
	# OPTIONS METHODS
	# ==================================================

	def _get_source(self, params, query=None):
		prefix = params.split()[0].lower()
		# if(prefix in ["query", "default"]):
		# 	query = ' '.join(params.split()[1:]
		# 					 ) if prefix == "query" else query
		# 	try:
		# 		results = self.query(query)
		#     except sqlite3.OperationalError as e:
		# 		raise framework.FrameworkException(
		# 			"Invalid source query. %s %s" % (type(e).__name__, e.message))
		# 	if(not results):
		# 		sources = []
		# 	elif(len(results[0]) > 1):
		# 		sources = [x[:len(x)] for x in results]
		# 		# raise framework.FrameworkException('Too many columns of data as source input.')
		# 	else:
		# 		sources = [x[0] for x in results]
		# el
		if(os.path.exists(params)):
			sources = open(params).read().split()
		else:
			sources = [params]
		if(not sources):
			raise framework.FrameworkException("Source contains no input.")
		return sources

	# ==================================================
	# SHOW METHODS
	# ==================================================

	def show_inputs(self):
		if(hasattr(self, "_default_source")):
			try:
				self._validate_options()
				inputs = self._get_source(
					self.options["source"], self._default_source)
				self.table([[x] for x in inputs], header=["Module Inputs"])
			except Exception as e:
				self.output(e.__str__())
		else:
			self.output("Source option not available for this module.")

	def show_source(self):
		for path in [os.path.join(x, "modules", self._modulename) + self.module_extention for x in (self.app_path, self._home)]:
			if(os.path.exists(path)):
				filename = path
		with open(filename) as f:
			content = f.readlines()
			nums = [str(x) for x in range(1, len(content)+1)]
			num_len = len(max(nums, key=len))
			for num in nums:
				print('%s|%s' % (num.rjust(num_len), content[int(num)-1]), end='')

	def show_info(self):
		self.meta["path"] = os.path.join(
			"modules", self._modulename) + self.module_extention
		print('')
		# meta info
		for item in ["name", "path", "author", "version"]:
			if self.meta.get(item):
				print('%s: %s' % (item.title().rjust(10), self.meta[item]))
		# required keys
		if(self.meta.get("required_keys")):
			print("%s: %s" % ("keys".title().rjust(10),
				  ", ".join(self.meta.get("required_keys"))))
		print('')
		# description
		if("description" in self.meta):
			print("Description:")
			print("%s%s" % (self.spacer, textwrap.fill(
				self.meta["description"], 100, subsequent_indent=self.spacer)))
			print('')
		# options
		print("Options:", end='')
		self.show_options()
		# sources
		if hasattr(self, "_default_source"):
			print("Source Options:")
			print("%s%s%s" %
				  (self.spacer, "default".ljust(15), self._default_source))
			print("%s%sstring representing a single input" %
				  (self.spacer, "<string>".ljust(15)))
			print("%s%spath to a file containing a list of inputs" %
				  (self.spacer, "<path>".ljust(15)))
			print('')
		# comments
		if("comments" in self.meta):
			print("Comments:")
			for comment in self.meta["comments"]:
				prefix = "* "
				if comment.startswith('\t'):
					prefix = self.spacer+"- "
					comment = comment[1:]
				print("%s%s" % (self.spacer, textwrap.fill(
					prefix+comment, 100, subsequent_indent=self.spacer)))
			print('')

	def show_globals(self):
		self.show_options(self._global_options)

	# ==================================================
	# UTIL METHODS
	# ==================================================

	def web_scrap(self, url, cookie=None, agent=None, proxy=None, timeout=None, multipage=False):
		scrap_at = web_scrap.web_scrap(framework=self, url=url, cookie=cookie,
									   agent=agent, proxy=proxy, timeout=timeout, multipage=multipage)
		return scrap_at

	def urlib(self, url):
		return urlib.urlib(url)

	def reglib(self):
		return reglib.reglib()

	def page_parse(self, resp):
		return page_parse.page_parse(self, resp)

	def google_engine(self, word, limit=100, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = google_engine.google_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return search_at

	def bing_engine(self, word, limit=100, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = bing_engine.bing_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return search_at

	def yahoo_engine(self, word, limit=100, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = yahoo_engine.yahoo_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		search_at.explore()
		return search_at

	def ask_engine(self, word, limit=200, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = ask_engine.ask_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return search_at

	def yandex_engine(self, word, limit=100, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = yandex_engine.yandex_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return search_at

	def baidu_engine(self, word, limit=200, cookie=None, agent=None, proxy=None, timeout=None):
		search_at = baidu_engine.baidu_engine(
			framework=self, word=word, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return search_at

	def wordlists(self):
		return wordlists.wordlists(self)

	def reverse_ip(self, nameserver, limit=300, cookie=None, agent=None, proxy=None, timeout=None):
		_reverse_ip = reverse_ip.reverse_ip(self, nameserver=nameserver, limit=limit, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _reverse_ip

	def social_nets(self, target, limit=200, bing=False, yahoo=False, cookie=None, agent=None, proxy=None, timeout=None):
		_social_nets = social_nets.social_nets(
			self, target=target, limit=limit, bing=bing, yahoo=yahoo, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _social_nets

	def dns_find(self, target, limit=200, bing=False, yahoo=False, cookie=None, agent=None, proxy=None, timeout=None):
		_dns_find = dns_find.dns_find(self, target=target, limit=limit, bing=bing,
									  yahoo=yahoo, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _dns_find

	def godork(self, dork, limit=200, cookie=None, agent=None, proxy=None, timeout=None):
		_godork = godork.godork(self, dork=dork, limit=limit,
								cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _godork

	def page_search(self, nameserver, word, multipage=False, cookie=None, agent=None, proxy=None, timeout=None):
		_page_search = page_search.page_search(
			self, nameserver=nameserver, multipage=multipage, word=word, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _page_search

	def emails_find(self, target, limit=200, bing=False, yahoo=False, cookie=None, agent=None, proxy=None, timeout=None):
		_emails_find = emails_find.emails_find(
			self, target=target, limit=limit, bing=bing, yahoo=yahoo, cookie=cookie, agent=agent, proxy=proxy, timeout=timeout)
		return _emails_find
	# ==================================================
	# COMMAND METHODS
	# ==================================================

	def do_reload(self, params):
		'''Reloads the current module'''
		self._reload = 1
		return True

	def do_run(self, params):
		'''Runs the module'''
		try:
			self._summary_counts = {}
			self._validate_options()
			pre = self.module_pre()
			params = [pre] if pre is not None else []
			# provide input if a default query is specified in the module
			if(hasattr(self, "_default_source")):
				objs = self._get_source(
					self.options["source"], self._default_source)
				params.insert(0, objs)
			self.module_run(*params)
			self.module_post()
		except KeyboardInterrupt:
			print('')
		except Exception:
			self.print_exception()
		finally:
			# print module summary
			if(self._summary_counts):
				self.heading("Summary", level=0)
				for table in self._summary_counts:
					new = self._summary_counts[table][0]
					cnt = self._summary_counts[table][1]
					if(new > 0):
						method = getattr(self, "alert")
					else:
						method = getattr(self, "output")
					method("%d total (%d new) %s found." % (cnt, new, table))
				self._summary_counts = {}

	def module_pre(self):
		pass

	def module_run(self):
		pass

	def module_post(self):
		pass
