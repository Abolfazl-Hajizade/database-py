# -*- coding: utf-8 -*-

from __future__ import print_function
from contextlib import closing
import cmd
import codecs
import inspect
import json
import os
import random
import re
import socket
import sqlite3
import string
import subprocess
import sys
import traceback

from core.util import request

# =================================================
# SUPPORT CLASSES
# =================================================


class FrameworkException(Exception):
	pass


class Colors(object):
	N = '\033[m'  # native
	R = '\033[31m'  # red
	G = '\033[32m'  # green
	O = '\033[33m'  # orange
	B = '\033[34m'  # blue


class Options(dict):

	def __init__(self, *args, **kwargs):
		self.required = {}
		self.description = {}

		super(Options, self).__init__(*args, **kwargs)

	def __setitem__(self, name, value):
		super(Options, self).__setitem__(name, self._autoconvert(value))

	def __delitem__(self, name):
		super(Options, self).__delitem__(name)
		if name in self.required:
			del self.required[name]
		if name in self.description:
			del self.description[name]

	def _boolify(self, value):
		# designed to throw an exception if value is not a string
		# representation of a boolean
		return {'true': True, 'false': False}[value.lower()]

	def _autoconvert(self, value):
		if value in (None, True, False):
			return value
		elif (isinstance(value, basestring)) and value.lower() in ('none', "''", '""'):
			return None
		orig = value
		for fn in (self._boolify, int, float):
			try:
				value = fn(value)
				break
			except ValueError:
				pass
			except KeyError:
				pass
			except AttributeError:
				pass
		if isinstance(value, int) and '.' in str(orig):
			return float(orig)
		return value

	def init_option(self, name, value=None, required=False, description=''):
		self[name] = value
		self.required[name] = required
		self.description[name] = description

	def serialize(self):
		data = {}
		for key in self:
			data[key] = self[key]
		return data

# =================================================
# FRAMEWORK CLASS
# =================================================


class Framework(cmd.Cmd):
	prompt = ">>>"
	# mode flags
	_script = 0
	_load = 0
	# framework variables
	_global_options = Options()
	_loaded_modules = {}
	app_path = ''
	data_path = ''
	core_path = ''
	workspace = ''
	module_extention = ''
	_home = ''
	_record = None
	_spool = None
	_summary_counts = {}

	def __init__(self, params):
		cmd.Cmd.__init__(self)
		self._modulename = params
		self.ruler = '-'
		self.spacer = '  '
		self.time_format = '%Y-%m-%d %H:%M:%S'
		self.nohelp = "%s[!] No help on %%s%s" % (Colors.R, Colors.N)
		self.do_help.__func__.__doc__ = '''Displays this menu'''
		self.doc_header = "Commands (type [help|?] <topic>):"
		self.rpc_cache = []
		self._exit = 0

	# ==================================================
	# CMD OVERRIDE METHODS
	# ==================================================

	def default(self, line):
		self.do_shell(line)

	def emptyline(self):
		# disables running of last command when no command is given
		# return flag to tell interpreter to continue
		return 0

	def precmd(self, line):
		if Framework._load:
			print('\r', end='')
		if Framework._script:
			print('%s' % (line))
		if Framework._record:
			recorder = codecs.open(Framework._record, "ab", encoding="utf-8")
			recorder.write(("%s\n" % (line)).encode("utf-8"))
			recorder.flush()
			recorder.close()
		if Framework._spool:
			Framework._spool.write("%s%s\n" % (self.prompt, line))
			Framework._spool.flush()
		return line

	def onecmd(self, line):
		cmd, arg, line = self.parseline(line)
		if not line:
			return self.emptyline()
		if line == 'EOF':
			# reset stdin for raw_input
			sys.stdin = sys.__stdin__
			Framework._script = 0
			Framework._load = 0
			return 0
		if cmd is None:
			return self.default(line)
		self.lastcmd = line
		if cmd == '':
			return self.default(line)
		else:
			try:
				func = getattr(self, "do_" + cmd)
			except AttributeError:
				return self.default(line)
			return func(arg)

	# make help menu more attractive
	def print_topics(self, header, cmds, cmdlen, maxcol):
		if cmds:
			self.stdout.write("%s\n" % str(header))
			if self.ruler:
				self.stdout.write("%s\n" % str(self.ruler * len(header)))
			for cmd in cmds:
				self.stdout.write("%s %s\n" % (
					cmd.ljust(15), getattr(self, "do_" + cmd).__doc__))
			self.stdout.write('\n')

	# ==================================================
	# SUPPORT METHODS
	# ==================================================

	def to_unicode_str(self, obj, encoding="utf-8"):
		# checks if obj is a string and converts if not
		if not isinstance(obj, basestring):
			obj = str(obj)
		obj = self.to_unicode(obj, encoding)
		return obj

	def to_unicode(self, obj, encoding="utf-8"):
		# checks if obj is a unicode string and converts if not
		if isinstance(obj, basestring):
			if not isinstance(obj, unicode):
				obj = unicode(obj, encoding)
		return obj

	def _parse_rowids(self, rowids):
		xploded = []
		rowids = [x.strip() for x in rowids.split(',')]
		for rowid in rowids:
			try:
				if('-' in rowid):
					start = int(rowid.split('-')[0].strip())
					end = int(rowid.split('-')[-1].strip())
					xploded += range(start, end + 1)
				else:
					xploded.append(int(rowid))
			except ValueError:
				continue
		return sorted(list(set(xploded)))

	# ==================================================
	# OUTPUT METHODS
	# ==================================================

	def print_exception(self, line=''):
		stack_list = [x.strip()
					  for x in traceback.format_exc().strip().splitlines()]
		line = ' '.join([x for x in [stack_list[-1], line] if x])
		if(self._global_options["verbosity"] == 1):
			if(len(stack_list) > 3):
				line = os.linesep.join((stack_list[-1], stack_list[-3]))
		elif(self._global_options["verbosity"] == 2):
			print('%s%s' % (Colors.R, '-' * 60))
			traceback.print_exc()
			print('%s%s' % ('-' * 60, Colors.N))
		self.error(line)

	def error(self, line):
		'''Formats and presents errors.'''
		if(not re.search(r'[.,;!?]$', line)):
			line += '.'
		line = line[:1].upper() + line[1:]
		print("%s[!] %s%s" % (Colors.R, self.to_unicode(line), Colors.N))

	def output(self, line):
		'''Formats and presents normal output.'''
		print("%s[*]%s %s" % (Colors.B, Colors.N, self.to_unicode(line)))

	def alert(self, line):
		'''Formats and presents important output.'''
		print("%s[*]%s %s" % (Colors.G, Colors.N, self.to_unicode(line)))

	def verbose(self, line):
		'''Formats and presents output if in verbose mode.'''
		if self._global_options["verbosity"] >= 1:
			self.output(line)

	def debug(self, line):
		'''Formats and presents output if in debug mode (very verbose).'''
		if self._global_options["verbosity"] >= 2:
			self.output(line)

	def heading(self, line, level=1):
		'''Formats and presents styled header text'''
		line = self.to_unicode(line)
		print('')
		if(level == 0):
			print(self.ruler * len(line))
			print(line.upper())
			print(self.ruler * len(line))
		if(level == 1):
			print("%s%s" % (self.spacer, line.title()))
			print("%s%s" % (self.spacer, self.ruler * len(line)))

	# ==================================================
	# ADD METHODS
	# ==================================================

	def _display(self, data, rowcount, pattern=None, keys=None):
		display = self.alert if rowcount else self.verbose
		if(pattern and keys):
			values = tuple([data[key] or "<blank>" for key in keys])
			display(pattern % values)
		else:
			for key in sorted(data.keys()):
				display("%s: %s" % (key.title(), data[key]))
			display(self.ruler * 50)

	# ==================================================
	# OPTIONS METHODS
	# ==================================================

	def register_option(self, name, value, required, description):
		self.options.init_option(
			name=name.lower(),
			value=value,
			required=required,
			description=description)
		# needs to be optimized rather than ran on every register
		self._load_config()

	def _validate_options(self):
		for option in self.options:
			# if value type is bool or int, then we know the options is set
			if(not type(self.options[option]) in [bool, int]):
				if(self.options.required[option] is True and not self.options[option]):
					raise FrameworkException(
						"Value required for the \'%s\' option." %
						(option.upper()))
		return

	def _load_config(self):
		config_path = os.path.join(self.workspace, "config.dat")
		# don't bother loading if a config file doesn't exist
		if os.path.exists(config_path):
			# retrieve saved config data
			with open(config_path) as config_file:
				try:
					config_data = json.loads(config_file.read())
				except ValueError:
					# file is corrupt, nothing to load, exit gracefully
					pass
				else:
					# set option values
					for key in self.options:
						try:
							self.options[key] = config_data[self._modulename][key]
						except KeyError:
							# invalid key, contnue to load valid keys
							continue

	def _save_config(self, name):
		config_path = os.path.join(self.workspace, "config.dat")
		# create a config file if one doesn't exist
		try:
			open(config_path, 'a').close()
		except IOError:
			os.chmod(config_path, 777)
		# retrieve saved config data
		with open(config_path) as config_file:
			try:
				config_data = json.loads(config_file.read())
			except ValueError:
				# file is empty or corrupt, nothing to load
				config_data = {}
		# create a container for the current module
		if self._modulename not in config_data:
			config_data[self._modulename] = {}
		# set the new option value in the config
		config_data[self._modulename][name] = self.options[name]
		# remove the option if it has been unset
		if config_data[self._modulename][name] is None:
			del config_data[self._modulename][name]
		# remove the module container if it is empty
		if not config_data[self._modulename]:
			del config_data[self._modulename]
		# write the new config data to the config file
		with open(config_path, 'w') as config_file:
			json.dump(config_data, config_file, indent=4)

	# ==================================================
	# REQUEST METHODS
	# ==================================================

	def request(self, url, **kwargs):
		req = request.req()
		req.user_agent = kwargs["agent"] if "agent" in kwargs else self._global_options["user-agent"]
		req.debug = True if self._global_options['verbosity'] >= 2 else False
		req.proxy = kwargs["proxy"] if "proxy" in kwargs else self._global_options["proxy"]
		req.timeout = kwargs["timeout"] if "timeout" in kwargs else self._global_options["timeout"]
		req.redirect = kwargs["redirect"] if "redirect" in kwargs else True
		method = kwargs["method"] if "method" in kwargs else "GET"
		payload = kwargs["payload"] if "payload" in kwargs else None
		headers = kwargs["headers"] if "headers" in kwargs else None
		cookie = kwargs["cookie"] if "cookie" in kwargs else None
		auth = kwargs["auth"] if "auth" in kwargs else None
		content = kwargs["content"] if "content" in kwargs else ''
		return req.send(
			url,
			method=method,
			payload=payload,
			headers=headers,
			cookie=cookie,
			auth=auth,
			content=content)

	# ==================================================
	# SHOW METHODS
	# ==================================================

	def show_modules(self, param):
		# process parameter according to type
		if(isinstance(param, list)):
			modules = param
		elif(param):
			modules = [
				x for x in Framework._loaded_modules if x.startswith(param)]
			if(not modules):
				self.error("Invalid module category.")
				return
		else:
			modules = Framework._loaded_modules
		if(not modules):
			self.error("no modules to display.")
			return
		# display the modules
		key_len = len(max(modules, key=len)) + len(self.spacer)
		last_category = ''
		for module in sorted(modules):
			category = module.split('/')[0]
			if(category != last_category):
				# print header
				last_category = category
				self.heading(last_category)
			# print module
			print("%s%s" % (self.spacer * 2, module))
		print('')

	def show_options(self, options=None):
		'''Lists options'''
		if(options is None):
			options = self.options
		if(options):
			pattern = "%s%%s  %%s  %%s  %%s" % (self.spacer)
			key_len = len(max(options, key=len))
			if(key_len < 4):
				key_len = 4
			val_len = len(max([self.to_unicode_str(options[x])
							   for x in options], key=len))
			if(val_len < 13):
				val_len = 13
			print('')
			print(pattern % ("Name".ljust(key_len), "Current Value".ljust(
				val_len), "Required", "Description"))
			print(
				pattern %
				(self.ruler *
				 key_len,
				 (self.ruler *
				  13).ljust(val_len),
					self.ruler *
					8,
					self.ruler *
					11))
			for key in sorted(options):
				value = options[key] if options[key] is not None else ''
				reqd = "no" if options.required[key] is False else "yes"
				desc = options.description[key]
				print(
					pattern %
					(key.upper().ljust(key_len),
					 self.to_unicode_str(value).ljust(val_len),
					 self.to_unicode_str(reqd).ljust(8),
					 desc))
			print('')
		else:
			print('')
			print("%sNo options available for this module." % (self.spacer))
			print('')

	def _get_show_names(self):
		# Any method beginning with "show_" will be parsed
		# and added as a subcommand for the show command.
		prefix = "show_"
		return [x[len(prefix):]
				for x in self.get_names() if x.startswith(prefix)]

	# ==================================================
	# COMMAND METHODS
	# ==================================================

	def do_exit(self, params):
		'''Exits the framework'''
		self._exit = 1
		return True

	# alias for exit
	def do_back(self, params):
		'''Exits the current context'''
		return True

	def do_set(self, params):
		'''Sets module options'''
		options = params.split()
		if(len(options) < 2):
			self.help_set()
			return
		name = options[0].lower()
		if(name in self.options):
			value = ' '.join(options[1:])
			self.options[name] = value
			print("%s => %s" % (name.upper(), value))
			self._save_config(name)
		else:
			self.error("Invalid option.")

	def do_unset(self, params):
		'''Unsets module options'''
		self.do_set('%s %s' % (params, "None"))

	def do_show(self, params):
		'''Shows various framework items'''
		if(not params):
			self.help_show()
			return
		_params = params
		params = params.lower().split()
		arg = params[0]
		params = ' '.join(params[1:])
		if(arg in self._get_show_names()):
			func = getattr(self, "show_" + arg)
			if(arg == "modules"):
				func(params)
			else:
				func()
		else:
			self.help_show()

	def do_search(self, params):
		'''Searches available modules'''
		if(not params):
			self.help_search()
			return
		text = params.split()[0]
		self.output("Searching for \'%s\'..." % (text))
		modules = [x for x in Framework._loaded_modules if text in x]
		if(not modules):
			self.error("No modules found containing \'%s\'." % (text))
		else:
			self.show_modules(modules)

	def do_shell(self, params):
		'''Executes shell commands'''
		proc = subprocess.Popen(params, shell=True, stdout=subprocess.PIPE,
								stderr=subprocess.PIPE, stdin=subprocess.PIPE)
		self.output("Command: %s" % (params))
		stdout = proc.stdout.read()
		stderr = proc.stderr.read()
		if(stdout):
			print('%s%s%s' % (Colors.O, stdout, Colors.N), end='')
		if(stderr):
			print('%s%s%s' % (Colors.R, stderr, Colors.N), end='')

	def do_resource(self, params):
		'''Executes commands from a resource file'''
		if(not params):
			self.help_resource()
			return
		if(os.path.exists(params)):
			sys.stdin = open(params)
			Framework._script = 1
		else:
			self.error("Script file \'%s\' not found." % (params))

	def do_load(self, params):
		'''Loads selected module'''
		if(not params):
			self.help_load()
			return
		# finds any modules that contain params
		modules = [params] if params in Framework._loaded_modules else [
			x for x in Framework._loaded_modules if params in x]
		# notify the user if none or multiple modules are found
		if(len(modules) != 1):
			if(not modules):
				self.error("Invalid module name.")
			else:
				self.output("Multiple modules match \'%s\'." % params)
				self.show_modules(modules)
			return
		import StringIO
		# compensation for stdin being used for scripting and loading
		if(Framework._script):
			end_string = sys.stdin.read()
		else:
			end_string = "EOF"
			Framework._load = 1
		sys.stdin = StringIO.StringIO("load %s\n%s" % (modules[0], end_string))
		return True
	do_use = do_load

	# ==================================================
	# HELP METHODS
	# ==================================================

	def help_load(self):
		print(getattr(self, "do_load").__doc__)
		print('')
		print("Usage: [load|use] <module>")
		print('')

	help_use = help_load

	def help_resource(self):
		print(getattr(self, "do_resource").__doc__)
		print('')
		print("Usage: resource <filename>")
		print('')

	def help_search(self):
		print(getattr(self, "do_search").__doc__)
		print('')
		print("Usage: search <string>")
		print('')

	def help_set(self):
		print(getattr(self, "do_set").__doc__)
		print('')
		print("Usage: set <option> <value>")
		self.show_options()

	def help_unset(self):
		print(getattr(self, "do_unset").__doc__)
		print('')
		print("Usage: unset <option>")
		self.show_options()

	def help_shell(self):
		print(getattr(self, "do_shell").__doc__)
		print('')
		print("Usage: [shell|!] <command>")
		print("...or just type a command at the prompt.")
		print('')

	def help_show(self):
		options = sorted(self._get_show_names())
		print(getattr(self, "do_show").__doc__)
		print('')
		print("Usage: show [%s]" % ('|'.join(options)))
		print('')

	# ==================================================
	# COMPLETE METHODS
	# ==================================================

	def complete_load(self, text, *ignored):
		return [x for x in Framework._loaded_modules if x.startswith(text)]
	complete_use = complete_load

	def complete_set(self, text, *ignored):
		return [x.upper()
				for x in self.options if x.upper().startswith(text.upper())]

	complete_unset = complete_set

	def complete_show(self, text, line, *ignored):
		args = line.split()
		if(len(args) > 1 and args[1].lower() == 'modules'):
			if(len(args) > 2):
				return [
					x for x in Framework._loaded_modules if x.startswith(
						args[2])]
			else:
				return [x for x in Framework._loaded_modules]
		options = sorted(self._get_show_names())
		return [x for x in options if x.startswith(text)]
