# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup


class web_scrap:
	"""docstring for web_scrap"""

	def __init__(self, framework, url, agent,
				 timeout, cookie, proxy, multipage):
		self.framework = framework
		self.agent = agent
		self.multipage = multipage
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.soup = BeautifulSoup
		self.urlib = self.framework.urlib
		self.url = self.urlib(url).sub_service(serv="http")
		self._pages_category = {}
		self._pages = ''
		self._links = []
		self._foreign_links = []
		self._get_links = []

	def run_crawl(self):
		final_links = []

		def notin(key, _list):
			if(key not in _list):
				_list.append(key)
			return _list

		def notin_final(key):
			if(key not in final_links):
				final_links.append(key)

		def islocal(url):
			if(re.match(self.url, url)):
				return True
			else:
				return False

		def get_source(url):
			links = []
			req = self.framework.request(
				url=url,
				cookie=self.cookie,
				agent=self.agent,
				proxy=self.proxy,
				timeout=self.timeout)
			if(req.status_code != 200):
				return False
			else:
				resp = req.text

			soup = self.soup(resp, "html.parser")
			get_a = soup.find_all('a', href=True)
			for i in get_a:
				i = i.get("href")
				urparse = self.urlib(i)
				urparse2 = self.urlib(url)
				if(i == '' or i == ' ' or i == '/'):
					continue
				elif(i[0] == '#'):
					continue
				elif(i[0] == '/' and len(i) > 1):
					i = urparse2.join(urparse.get_path)
				else:
					pass

				urparse = self.urlib(i)
				if(urparse.get_netloc.lower() not in self.url.lower()):
					self._foreign_links.append(i)
					continue
				if(urparse.get_query != ""):
					notin(str(i), self._get_links)
				notin(i, links)
				notin_final(i)

			if(resp != ""):
				self._pages = self._pages + resp.encode("utf-8")
				self._pages_category[url] = resp.encode("utf-8")
			return links

		lnks = get_source(self.url)
		if(not lnks):
			return [self.url]
		elif(lnks is not []):
			notin_final(self.url)
		else:
			pass

		if(not self.multipage):
			self._links = final_links
			return

		for i in lnks:
			lnks1 = get_source(i)
			if(not lnks1):
				continue
			for j in lnks1:
				lnks2 = get_source(j)
				if(not lnks2):
					continue
				for k in lnks2:
					lnks3 = get_source(k)
					if(not lnks3):
						continue

		self._links = final_links

	@property
	def get_pages(self):
		return self._pages

	@property
	def get_pages_category(self):
		return self._pages_category

	@property
	def get_links(self):
		return self._links

	@property
	def get_foreign_links(self):
		return self._foreign_links

	@property
	def get_get_links(self):
		return self._get_links
