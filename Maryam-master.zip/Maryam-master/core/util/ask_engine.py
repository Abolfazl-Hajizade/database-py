# -*- coding: utf-8 -*-
import re


class ask_engine:
	"""docstring for ask_engine"""

	def __init__(self, framework, word, limit, agent, timeout, cookie, proxy):
		self.framework = framework
		self.agent = agent
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.word = word
		self.results = ''
		self.nextresults = ''
		self.ask = "www.ask.com"
		self.limit = limit
		self.count = 0

	def searcher(self):
		url = "https://" + self.ask + "/web?q=" + \
			self.word + "&pu=100&page=" + str(self.count)
		req = self.framework.request(
			url=url,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		self.results = req.text
		self.nextresults += self.results

	def next(self):
		nextres = self.framework.page_parse(self.results).findall(r"> Next <")
		if nextres != []:
			nexty = '1'
		else:
			nexty = '0'
		return nexty

	def run_crawl(self):
		while(self.count < self.limit):
			self.searcher()
			more = self.next()
			if more == '1':
				self.counter += 100
			else:
				break

	@property
	def get_pages(self):
		return self.nextresults
