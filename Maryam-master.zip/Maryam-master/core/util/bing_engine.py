# -*- coding: utf-8 -*-


class bing_engine:
	"""docstring for bing_engine"""

	def __init__(self, framework, word, limit, agent, timeout, cookie, proxy):
		self.framework = framework
		self.agent = agent
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.word = word
		self.results = ''
		self.nextresults = ''
		self.bing = "www.bing.com"
		self.limit = limit  # 100
		self.count = 10

	def searcher(self):
		url = "http://" + self.bing + "/search?q=" + \
			self.word + "&count=50&first=" + str(self.count)
		req = self.framework.request(
			url=url,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		self.results = req.text
		self.nextresults += self.results

	def run_crawl(self):
		while(self.count < self.limit):
			self.searcher()
			self.count += 50

	@property
	def get_pages(self):
		return self.nextresults
