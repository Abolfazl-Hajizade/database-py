# -*- coding: utf-8 -*-


class google_engine:
	"""docstring for google_engine"""

	def __init__(self, framework, word, limit, agent, timeout, cookie, proxy):
		self.framework = framework
		self.agent = agent
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.word = word
		self.results = ""
		self.nextresults = ""
		self.google = "www.google.com"
		self.quantity = "100"
		self.limit = limit
		self.count = 0

	def searcher(self):
		url = "http://" + self.google + "/search?num=" + self.quantity + \
			"&start=" + str(self.count) + "&hl=en&meta=&q=" + self.word
		req = self.framework.request(
			url=url,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		self.results = req.text
		self.nextresults += self.results

	def run_crawl(self):
		while(self.count < self.limit):
			self.searcher()
			self.count += 100

	@property
	def get_pages(self):
		return self.nextresults
