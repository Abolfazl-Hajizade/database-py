# -*- coding: utf-8 -*-
import re


class reglib:
	"""docstring for reglib"""

	def __init__(self):
		self.protocol_s = r"^([a-zA-Z0-9]+:\/\/)"
		self.protocol_m = r"([a-zA-Z0-9]+:\/\/)"
		self.email_s = r"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6}$"
		self.email_m = r"\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6}"
		self.phone_s = r"^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4}|[a-zA-Z0-9]{7})$"
		self.phone_m = r"([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4}|[a-zA-Z0-9]{7})"
		self.domain_s = r"^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}(\:[0-9]{1,5})*$"
		self.domain_m = r"[a-zA-Z0-9\-]{0,61}\.+[a-zA-Z]{2,6}"
		self.url_s = r"^([a-zA-Z0-9]+:\/\/)?(www.|[a-zA-Z0-9].)[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,6}(\:[0-9]{1,5})*(\/($|[a-zA-Z0-9\.\,\;\?\'\\\+&amp;%\$#\=~_\-]+))*$"
		self.url_m = r"ftp|https?:\/\/[a-zA-Z0-9\-]{2,255}\.[a-zA-Z]{2,6}[\/a-zA-Z0-9\.\,\;\?\'\\\+&amp;%\$#\=~_\-]+"
		self.ipv4_s = r"^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$"
		self.ipv4_m = r"(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])"
		self.id_s = r"^@[a-zA-Z_0-9\.\-]{2,255}$"
		self.id_m = r"@[a-zA-Z_0-9\.\-]{2,255}"
		self.wordpress = [
			r"\<meta name\=\"generator\" content\=\"WordPress.com\" \/\>",
			r"\<a href\=\"http://www.wordpress.com\"\>Powered by WordPress\<\/a\>",
			r"\<link rel\=\'https://api.w.org/\'",
			r"\/wp-content\/plugins\/"]
		self.joomla_cookie = r"mosvisitor="
		self.joomla = [
			r"\<meta name\=\"Generator\" content\=\"Joomla! - Copyright \(C\) 200[0-9] - 200[0-9] Open Source Matters. All rights reserved.\" \/\>",
			r"\<meta name\=\"generator\" content\=\"Joomla! (\d\.\d) - Open Source Content Management\" \/\>",
			r"Powered by \<a href\=\"http://www.joomla.org\"\>Joomla!\<\/a\>."]
		self.magento_cookie = r"magento=[0-9a-f]+|frontend=[0-9a-z]+"
		self.magento = [
			r"images/logo.gif\" alt\=\"Magento Commerce\" \/\>\<\/a\>\<\/h1\>",
			r"\<a href\=\"http://www.magentocommerce.com/bug-tracking\" id\=\"bug_tracking_link\"\>\<strong\>Report All Bugs\<\/strong\>\<\/a\>",
			r"\<link rel\=\"stylesheet\" type\=\"text/css\" href\=\"[^\"]+\/skin\/frontend\/[^\"]+\/css\/boxes.css\" media\=\"all\"",
			r"\<div id\=\"noscript-notice\" class\=\"magento-notice\"\>",
			r"Magento is a trademark of Magento Inc. Copyright &copy; ([0-9]{4}) Magento Inc"]
		self.adobeaem = [
			r"<link[^>]*stylesheet[^>]*etc\/designs\/[^>]*\>[^<]*",
			r"<link[^>]*etc\/clientlibs\/[^>]*\>[^<]*",
			r"<script[^>]*etc\/clientlibs\/[^>]*\>[^<]*",
			r"<script[^>]*\/granite\/[^>]*(\.js\")+\>[^<]*"]
		self.bolt = [
			r"/bolt-public/img/",
			r"/theme/bolt/v[0-9]{2,6}/styles/",
			r"<!-- This site is being optimized with the Bob Bolt SEO Premium Extension. v[0-9]{1,3}.[0-9]{1,3}.{0-9}{1,3} Platinum Edition Pro\. -->"]
		self.drupal_cookie = r"SESS[a-z0-9]{32}=[a-z0-9]{32}"
		self.drupal = [
			r"\<script type\=\"text\/javascript\" src\=\"[^\"]*\/misc\/drupal.js[^\"]*\"\>\<\/script\>",
			r"<[^>]+alt\=\"Powered by Drupal, an open source content management system\"",
			r"@import \"[^\"]*\/misc\/drupal.css\"",
			r"jQuery.extend\(drupal\.S*",
			r"Drupal.extend\(\S*"]
		self.silverstripe_cookie = r"PastVisitor=[0-9]+.*"
		self.silverstripe = [
			r"\<meta name\=\"generator\"[^>]*content\=\"SilverStripe",
			r"\<link[^>]*stylesheet[^>]*layout.css[^>]*\>[^<]*\<link[^>]*stylesheet[^>]*typography.css[^>]*\>[^<]*\<link[^>]*stylesheet[^>]*form.css[^>]*\>",
			r"\<img src\=\"\/assets\/[^\/]+\/_resampled\/[^\"]+.jpg\""]
		self.plone_header = [r"x-caching-rule(-id)?",
							 r"plone-content-types", ]
		self.plone = [
			r"\<meta name\=\"generator\" content\=\"[^>]*http:\/\/plone.org\" \/>",
			r"(@import url|text\/css)[^>]*portal_css\/.*plone.*css(\)|\")",
			r"src\=\"[^\"]*ploneScripts[0-9]+.js\"",
			r"\<div class\=\"visualIcon contenttype-plone-site\"\>"]
		self.social_network_ulinks = {
			"instagram": r"(instagram)\.com/([a-zA-Z_0-9]{2,255})",
			"facebook": r"(facebook)\.com/([a-zA-Z_0-9]{2,255})",
			"twitter": r"(twitter)\.com/([a-zA-Z_0-9]{2,255})",
			"github": r"(github)\.com/([a-zA-Z_0-9]{2,255})",
			"telegram": r"(telegram)\.me/([a-zA-Z_0-9]{2,255})",
			"youtube": r"(youtube)\.com/user/([a-zA-Z_0-9]{2,255})",
			"linkedin": r"(linkedin)\.com/company/([a-zA-Z_0-9\.\-]{2,255})"}

	def search(self, string, regex, _type=list):
		res = [] if _type is list else False
		regex = re.findall(regex, string)
		if(regex != []):
			if(_type is bool):
				return True
			for i in regex:
				if(isinstance(i, tuple)):
					i = "".join(i)
					if i not in res:
						res.append(i)
				else:
					if i not in res:
						res.append(i)
		else:
			return None

	def sub(self, regex, sub_string, string):
		data = re.sub(regex, sub_string, str(string))
		return data

	def is_email(self, string):
		return self.search(string, self.email_s, _type=bool)

	def is_id(self, string):
		return self.search(string, self.id_s, _type=bool)

	def is_protocol(self, string):
		return self.search(string, self.protocol_s, _type=bool)

	def is_phone(self, string):
		return self.search(string, self.phone_s, _type=bool)

	def is_domain(self, string):
		return self.search(string, self.domain_s, _type=bool)

	def is_url(self, string):
		return self.search(string, self.url_s, _type=bool)

	def is_ipv4(self, string):
		return self.search(string, self.ipv4_s, _type=bool)

	def is_wordpress(self, string):
		mode = False
		for i in self.wordpress:
			mode |= self.search(string, i, _type=bool) is not None
		return mode

	def is_joomla(self, string, headers):
		mode = False
		if(self.search(self.joomla_cookie, headers["set-cookie"])):
			mode |= True
		for i in self.joomla:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_bolt(self, string):
		mode = False
		for i in self.bolt:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_magento(self, string, headers):
		mode = False
		if(self.search(self.magento_cookie, headers["set-cookie"])):
			mode |= True
		for i in self.magento:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_plone(self, string, headers):
		mode = False
		for i in self.plone_header:
			mode |= self.search(str(headers), i, _type=bool)
		for i in self.plone:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_drupal(self, string, headers):
		mode = False
		if(self.search(self.drupal_cookie, headers["set-cookie"])):
			mode |= True
		for i in self.drupal:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_silverstripe(self, string, headers):
		mode = False
		if(self.search(self.silverstripe_cookie, headers["set-cookie"])):
			mode |= True
		for i in self.silverstripe:
			mode |= self.search(string, i, _type=bool)
		return mode

	def is_adobeaem(self, string):
		mode = False
		for i in self.adobeaem:
			mode |= self.search(string, i, _type=bool)
		return mode

	def ge_email(self, string):
		return self.search(string, self.email_m, _type=list)

	def get_ipv4(self, string):
		return self.search(string, self.ipv4_m, _type=list)

	def get_domain(self, string):
		return self.search(string, self.domain_m, _type=list)

	def get_url(self, string):
		return self.search(self.url_m, _type=list)

	def get_phone(self, string):
		return self.search(string, self.phone_m, _type=list)

	def get_id(self, string):
		return self.search(string, self.id_m, _type=list)
