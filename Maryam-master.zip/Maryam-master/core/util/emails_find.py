# -*- coding: utf-8 -*-


class emails_find:
	"""docstring for email_find"""

	def __init__(
			self,
			framework,
			target,
			limit,
			yahoo=False,
			bing=False,
			cookie=None,
			agent=None,
			proxy=None,
			timeout=None):
		self.framework = framework
		self.cookie = cookie
		self.agent = agent
		self.proxy = proxy
		self.timeout = timeout
		self.target = target
		self.limit = limit
		self.yahoo = yahoo
		self.bing = bing
		self._get_emails = []

	def run_crawl(self):
		if(self.limit < 100):
			self.limit = 100
		if(self.limit > 1000):
			self.limit = 1000

		pages = ""
		google = self.framework.google_engine(
			word="%40\"" + self.target + '\"',
			limit=self.limit,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		google.run_crawl()
		pages = pages + google.get_pages
		if(self.bing):
			bing = self.framework.bing_engine(
				word="%40" + self.target,
				limit=self.limit,
				cookie=self.cookie,
				agent=self.agent,
				proxy=self.proxy,
				timeout=self.timeout)
			bing.run_crawl()
			pages = pages + bing.get_pages
		if(self.yahoo):
			yahoo = self.framework.yahoo_engine(
				word="\"%40" + self.target + '\"',
				limit=self.limit,
				cookie=self.cookie,
				agent=self.agent,
				proxy=self.proxy,
				timeout=self.timeout)
			yahoo.run_crawl()
			pages = pages + yahoo.get_pages

		self._get_emails = self.framework.page_parse(
			pages).get_emails(self.target)

	@property
	def get_emails(self):
		return self._get_emails
