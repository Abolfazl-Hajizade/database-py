# -*- coding : u8 -*-
import re as _re


class page_parse:
	"""docstring for page_parse"""

	def __init__(self, framework, page):
		self.framework = framework
		self.page = page

	def generic_clean(self):
		self.page = _re.sub("<em>", '', self.page)
		self.page = _re.sub("<b>", '', self.page)
		self.page = _re.sub("</b>", '', self.page)
		self.page = _re.sub("</em>", '', self.page)
		self.page = _re.sub("%2f", ' ', self.page)
		self.page = _re.sub("%3a", ' ', self.page)
		self.page = _re.sub("<strong>", '', self.page)
		self.page = _re.sub("</strong>", '', self.page)
		self.page = _re.sub("<wbr>", '', self.page)
		self.page = _re.sub("</wbr>", '', self.page)

	def findall(self, re):
		re = _re.compile(re)
		return re.findall(self.page)

	def get_sites(self):
		self.generic_clean()
		re = _re.compile(r"<cite>(.*?)</cite>")
		resp = []
		for i in re.findall(self.page):
			if(i not in resp):
				resp.append(i)
		return resp

	def get_social_nets(self):
		self.generic_clean()
		reg_id = self.framework.reglib().social_network_ulinks
		resp = []
		for i in reg_id:
			_id = _re.findall(reg_id[i], self.page)
			_id2 = []
			_id2 = [x for x in _id if x not in _id2]
			for i in _id2:
				network = {i[0]: i[1]}
				if(network not in resp):
					resp.append(network)
		return resp

	def get_emails(self, host):
		self.generic_clean()
		re = _re.compile(
			r"[a-zA-Z0-9.\-_+#~!$&\',;=:]+" +
			'@' +
			r"[a-zA-Z0-9.-]*" +
			host)
		resp = []
		for i in re.findall(self.page):
			if(i not in resp):
				resp.append(i)
		return resp

	def get_dns(self, host):
		self.generic_clean()
		re = _re.compile(r'[a-zA-Z0-9.-]*\.' + host)
		resp = []
		for i in re.findall(self.page):
			if(i not in resp):
				resp.append(i)
		return resp
