# -*- coding: utf-8 -*-


class yahoo_engine:
	"""docstring for yahoo_engine"""
	def __init__(self, framework, word, limit, agent, timeout, cookie, proxy):
		self.agent = agent
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.framework = framework
		self.word = word
		self.results = ''
		self.nextresults = ''
		self.yahoo = "www.search.yahoo.com"
		self.limit = limit  # 100
		self.count = 0

	def searcher(self):
		url = "http://" + self.yahoo + "/search?p=" + \
			self.word + "&b=" + str(self.count) + "&pz=10"
		req = self.framework.request(
			url=url,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		self.results = req.text
		self.nextresults += self.results

	def run_crawl(self):
		while(self.count < self.limit):
			self.searcher()
			self.count += 10

	@property
	def get_pages(self):
		return self.nextresults
