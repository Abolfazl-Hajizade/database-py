# -*- coding: utf-8 -*-
import os


class wordlists:
	"""docstring for wordlist"""

	def __init__(self, framework):
		self.framework = framework

	def fopen(self, filename):
		file = os.path.join(self.framework.data_path, filename)
		if(os.path.exists(file)):
			try:
				fopen = open(file).read()
			except Exception as e:
				self.framework.error(e)
			else:
				print fopen
				return fopen
		else:
			self.framework.error("traversal wordlist not found")

	@property
	def get_interest_direct(self):
		return self.fopen("interest_direct")

	@property
	def get_interest_files(self):
		return self.fopen("interest_files")

	@property
	def get_traversal(self):
		return self.fopen("traversal")
