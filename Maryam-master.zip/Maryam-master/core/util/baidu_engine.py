# -*- coding: utf-8 -*-


class baidu_engine:
	"""docstring for baidu_engine"""

	def __init__(self, framework, word, limit, agent, timeout, cookie, proxy):
		self.agent = agent
		self.timeout = timeout
		self.cookie = cookie
		self.proxy = proxy
		self.framework = framework
		self.word = word
		self.results = ''
		self.nextresults = ''
		self.baidu = "www.baidu.com"
		self.limit = limit
		self.count = 0

	def searcher(self):
		url = "http://" + self.baidu + "/s?wd=" + self.word + \
			"&pn=" + str(self.count) + "&oq=" + self.word
		req = self.framework.request(
			url=url,
			cookie=self.cookie,
			agent=self.agent,
			proxy=self.proxy,
			timeout=self.timeout)
		self.results = req.text
		self.nextresults += self.results

	def run_crawl(self):
		cond1 = self.count <= self.limit
		cond2 = self.count <= 1000
		while(cond1 and cond2):
			self.searcher()
			self.count += 100

	@property
	def get_pages(self):
		return self.nextresults
