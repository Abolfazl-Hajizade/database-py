#! /usr/bin/python2
# -*- coding: utf-8 -*-

import sys
import platform
from core import base
from core.framework import Colors
#if platform.system() not in ["Linux", "Darwin"]:
#    print("[!] Sorry, this tool is designed for Linux and Mac !")
#    sys.exit()

sys.dont_write_bytecode = True


def maryam_ui():
    x = base.Base(base.Mode.CONSOLE)
    try:
        x.cmdloop()
    except KeyboardInterrupt:
        print('')


maryam_ui()
